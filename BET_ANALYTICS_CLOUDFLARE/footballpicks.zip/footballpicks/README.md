# ⚽ Pronostics Foot du Jour

Application web locale qui analyse les matchs du jour et propose, pour chaque
match :
- la probabilité de **+2,5 buts** (modèle de Poisson basé sur la force
  d'attaque/défense de chaque équipe à domicile/extérieur)
- une liste de **buteurs probables** avec leur probabilité de marquer

> ⚠️ C'est un outil statistique basé sur l'historique. Ça n'est pas une
> garantie de résultat — utile pour s'informer, pas pour parier à l'aveugle.

## 1. Obtenir une clé API gratuite

1. Va sur **https://www.api-football.com/** (ou via RapidAPI :
   https://rapidapi.com/api-sports/api/api-football)
2. Crée un compte gratuit
3. Dans ton tableau de bord, copie ta clé API (le plan **Free** donne
   100 requêtes/jour et l'accès à tous les endpoints, largement suffisant
   pour cette appli qui ne fait qu'une quinzaine d'appels par jour)

## 2. Installation

```bash
cd footballpicks
python3 -m venv venv
source venv/bin/activate        # sous Windows : venv\Scripts\activate
pip install -r requirements.txt
```

Copie ensuite `.env.example` vers `.env` et colle ta clé :

```bash
cp .env.example .env
# puis édite .env et remplace "colle_ta_cle_ici" par ta vraie clé
```

Tu peux aussi personnaliser la liste des championnats suivis via
`LEAGUE_IDS` dans `.env` (liste des IDs disponible sur le dashboard
API-Football).

## 3. Lancer l'appli

```bash
python app.py
```

Puis ouvre **http://localhost:5000** dans ton navigateur (PC ou mobile sur
le même réseau, en remplaçant `localhost` par l'IP locale de ta machine,
ex : `http://192.168.1.20:5000`).

## Comment ça marche

- **Matchs du jour** : un seul appel `GET /fixtures?date=...` récupère tous
  les matchs, filtrés localement sur les championnats suivis.
- **Force d'attaque/défense** : calculée à partir des classements
  (`GET /standings`), en comparant la moyenne de buts marqués/encaissés de
  chaque équipe à la moyenne de la ligue.
- **+2,5 buts** : les buts totaux attendus (λ_domicile + λ_extérieur)
  suivent une loi de Poisson ; on calcule `1 - P(0) - P(1) - P(2)`.
- **Buteurs probables** : basé sur les meilleurs buteurs de chaque
  championnat (`GET /players/topscorers`), avec leur ratio buts/match
  ajusté au nombre de buts attendus de leur équipe dans le match du jour.
- **Lissage début de saison** (`data_sources.py`) : les résultats de la
  saison précédente sont téléchargés gratuitement depuis
  **football-data.co.uk** (CSV publics, aucune clé requise) pour les 5
  grands championnats (Angleterre, France, Espagne, Italie, Allemagne).
  Tant que peu de matchs ont été joués cette saison, les moyennes de buts
  sont mélangées avec celles de la saison précédente (mélange bayésien
  simple : 100% saison précédente à 0 match joué, 100% saison en cours à
  partir de 10 matchs joués). Ça évite des pronostics erratiques en août/
  septembre.
- **Cache** : les réponses API sont mises en cache 6h (24h pour les CSV
  football-data.co.uk) sur disque (dossier `cache/`) pour ne pas gaspiller
  le quota gratuit. Le bouton "Rafraîchir" vide le cache et recharge tout.

### Pourquoi pas Mackolik ou Pronosoft/Forebet ?

Ces sites ont été envisagés mais aucun ne propose d'API publique pour
développeurs — seulement des sites web destinés aux visiteurs humains. Les
récupérer nécessiterait du scraping, qui viole en général leurs conditions
d'utilisation (et, pour Pronosoft/Forebet, reproduirait directement leurs
pronostics propriétaires plutôt que des données brutes). L'app utilise donc
uniquement des sources aux conditions d'utilisation claires et compatibles
avec un usage développeur : API-Football et football-data.co.uk.

## Limites à connaître

- Le modèle ne prend pas en compte les **blessures/suspensions** de dernière
  minute, la météo, les enjeux psychologiques, etc.
- En début de saison (peu de matchs joués), les estimations sont moins
  fiables — le code utilise des valeurs par défaut neutres si une équipe a
  joué moins de 3 matchs à domicile/extérieur.
- La liste de buteurs se base sur les meilleurs buteurs **du championnat**,
  pas sur la feuille de match prévue (compositions probables) — un joueur
  blessé ou remplaçant peut apparaître.

## Déploiement en ligne (accessible depuis ton mobile, partout)

Pour ne pas dépendre de ton ordinateur allumé, héberge l'appli gratuitement
sur **Render.com** (le fichier `render.yaml` est déjà prêt) :

1. Crée un compte gratuit sur https://render.com et sur https://github.com
   (si tu n'en as pas déjà un)
2. Crée un nouveau dépôt GitHub et pousse-y ce dossier (`git init`,
   `git add .`, `git commit -m "init"`, puis suis les instructions GitHub
   pour "push an existing repository")
3. Sur Render : **New +** → **Blueprint** → connecte ton dépôt GitHub →
   Render détecte automatiquement `render.yaml`
4. Render te demandera la variable `API_FOOTBALL_KEY` → colle ta clé API
5. Clique **Deploy** → au bout de 2-3 minutes ton appli est en ligne à une
   adresse du type `https://football-picks.onrender.com`, accessible depuis
   n'importe quel appareil

(Le plan gratuit de Render met le service en veille après 15 min
d'inactivité — le premier chargement après une pause peut prendre ~30
secondes le temps qu'il se réveille.)

## Pour aller plus loin

- Ajouter les **compositions probables** (endpoint `/fixtures/lineups`,
  disponible ~1h avant le match) pour affiner les buteurs.
- Intégrer les **cotes des bookmakers** (`/odds`) pour comparer ton modèle
  au marché.
- Automatiser un rafraîchissement quotidien (cron / tâche planifiée) et
  envoyer un résumé par email ou notification.
