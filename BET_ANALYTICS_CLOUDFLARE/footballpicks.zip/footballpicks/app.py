"""
Football Picks - Pronostics quotidiens (buteurs probables + matchs +2,5 buts)
================================================================================

Utilise l'API gratuite API-Football (https://www.api-football.com/) pour
récupérer les matchs du jour, les classements (pour les moyennes de buts
domicile/extérieur) et les meilleurs buteurs de chaque championnat, puis
applique un modèle de Poisson pour estimer :

  1. La probabilité qu'un match totalise plus de 2,5 buts
  2. La probabilité que chaque buteur potentiel marque dans le match

⚠️ Ceci est un outil statistique, pas une garantie de résultat. Les paris
sportifs comportent un risque de perte d'argent ; jouez de façon responsable.

Configuration : copie .env.example vers .env et renseigne ta clé API.
"""

import os
import json
import time
import math
from datetime import date, datetime
from pathlib import Path

from flask import Flask, jsonify, render_template, request
import requests
from dotenv import load_dotenv

import data_sources

load_dotenv()

API_KEY = os.environ.get("API_FOOTBALL_KEY", "")
API_HOST = "v3.football.api-sports.io"
BASE_URL = f"https://{API_HOST}"

# Championnats suivis par défaut (id API-Football). Modifiable dans .env
# via LEAGUE_IDS="39,61,140,135,78,2" (Premier League, Ligue 1, Liga,
# Serie A, Bundesliga, Champions League).
DEFAULT_LEAGUES = [39, 61, 140, 135, 78, 2]
LEAGUE_IDS = [
    int(x) for x in os.environ.get("LEAGUE_IDS", "").split(",") if x.strip()
] or DEFAULT_LEAGUES

CACHE_DIR = Path(__file__).parent / "cache"
CACHE_DIR.mkdir(exist_ok=True)
CACHE_TTL_SECONDS = 6 * 3600  # 6h : les stats/classements ne changent pas vite

app = Flask(__name__)


# ---------------------------------------------------------------------------
# Couche d'accès à l'API (avec cache disque simple pour économiser le quota)
# ---------------------------------------------------------------------------

def _cache_path(key: str) -> Path:
    safe = key.replace("/", "_").replace("?", "_").replace("&", "_")
    return CACHE_DIR / f"{safe}.json"


def api_get(endpoint: str, params: dict) -> dict:
    """Appelle l'API-Football avec cache disque (TTL configurable)."""
    cache_key = f"{endpoint}_{json.dumps(params, sort_keys=True)}"
    cpath = _cache_path(cache_key)

    if cpath.exists():
        age = time.time() - cpath.stat().st_mtime
        if age < CACHE_TTL_SECONDS:
            return json.loads(cpath.read_text())

    if not API_KEY:
        raise RuntimeError(
            "Aucune clé API configurée. Renseigne API_FOOTBALL_KEY dans .env"
        )

    headers = {"x-apisports-key": API_KEY}
    resp = requests.get(f"{BASE_URL}/{endpoint}", headers=headers, params=params, timeout=15)
    resp.raise_for_status()
    data = resp.json()

    if data.get("errors"):
        # L'API renvoie souvent un dict d'erreurs non-fatal (ex: quota).
        # On ne casse pas tout, mais on le journalise.
        print(f"[API-Football] avertissement sur {endpoint}: {data['errors']}")

    cpath.write_text(json.dumps(data))
    return data


def current_season_year() -> int:
    """L'API-Football utilise l'année de début de saison (ex: 2026 pour 2026-27)."""
    today = date.today()
    # Les saisons européennes démarrent ~juillet/août
    return today.year if today.month >= 7 else today.year - 1


# ---------------------------------------------------------------------------
# Modèle statistique (Poisson)
# ---------------------------------------------------------------------------

def poisson_pmf(k: int, lam: float) -> float:
    return math.exp(-lam) * (lam ** k) / math.factorial(k)


def poisson_over_2_5(total_lambda: float) -> float:
    """P(total buts > 2.5) = 1 - P(0) - P(1) - P(2)."""
    p0 = poisson_pmf(0, total_lambda)
    p1 = poisson_pmf(1, total_lambda)
    p2 = poisson_pmf(2, total_lambda)
    return max(0.0, min(1.0, 1 - p0 - p1 - p2))


def poisson_prob_scores(lam_player: float) -> float:
    """P(le joueur marque au moins 1 but) = 1 - exp(-lambda)."""
    return max(0.0, min(1.0, 1 - math.exp(-lam_player)))


def compute_league_standings_stats(league_id: int, season: int) -> dict:
    """
    Retourne, par équipe (id), les moyennes de buts marqués/encaissés à
    domicile et à l'extérieur, plus les moyennes de la ligue entière
    (nécessaires comme référence pour la force d'attaque/défense).
    """
    data = api_get("standings", {"league": league_id, "season": season})
    try:
        standings_groups = data["response"][0]["league"]["standings"]
    except (IndexError, KeyError):
        return {"teams": {}, "league_avg_home_goals": 1.4, "league_avg_away_goals": 1.1}

    teams = {}
    home_goals_sum, home_played_sum = 0, 0
    away_goals_sum, away_played_sum = 0, 0

    for group in standings_groups:
        for row in group:
            team_id = row["team"]["id"]
            home = row.get("home", {})
            away = row.get("away", {})

            h_played = home.get("played", 0) or 0
            h_gf = home.get("goals", {}).get("for", 0) or 0
            h_ga = home.get("goals", {}).get("against", 0) or 0
            a_played = away.get("played", 0) or 0
            a_gf = away.get("goals", {}).get("for", 0) or 0
            a_ga = away.get("goals", {}).get("against", 0) or 0

            teams[team_id] = {
                "name": row["team"]["name"],
                "home_played": h_played,
                "home_gf_avg": (h_gf / h_played) if h_played else None,
                "home_ga_avg": (h_ga / h_played) if h_played else None,
                "away_played": a_played,
                "away_gf_avg": (a_gf / a_played) if a_played else None,
                "away_ga_avg": (a_ga / a_played) if a_played else None,
            }

            home_goals_sum += h_gf
            home_played_sum += h_played
            away_goals_sum += a_gf
            away_played_sum += a_played

    league_avg_home_goals = (home_goals_sum / home_played_sum) if home_played_sum else 1.4
    league_avg_away_goals = (away_goals_sum / away_played_sum) if away_played_sum else 1.1

    return {
        "teams": teams,
        "league_avg_home_goals": league_avg_home_goals,
        "league_avg_away_goals": league_avg_away_goals,
    }


def estimate_match_goals(home_id: int, away_id: int, league_stats: dict, prior_stats: dict | None = None):
    """
    Modèle classique (type Dixon-Coles simplifié) :
      force_attaque_domicile = (buts marqués/match à domicile) / (moyenne ligue domicile)
      force_defense_exterieur = (buts encaissés/match à l'ext.) / (moyenne ligue domicile)
      lambda_domicile = moyenne_ligue_domicile * force_attaque_domicile * force_defense_exterieur
      (symétrique pour l'équipe à l'extérieur)

    Si `prior_stats` est fourni (données football-data.co.uk de la saison
    précédente), les moyennes de buts de chaque équipe sont mélangées avec
    celles de la saison précédente tant que peu de matchs ont été joués
    cette saison (voir data_sources.blend_stat). Ça évite des estimations
    trop bruitées en tout début de championnat.
    """
    teams = league_stats["teams"]
    lha = league_stats["league_avg_home_goals"]
    laa = league_stats["league_avg_away_goals"]

    home = teams.get(home_id)
    away = teams.get(away_id)

    def _blended(team_row, prior_row, field_played, field_gf, field_ga):
        """Retourne (gf_avg, ga_avg, played) après mélange avec la saison précédente."""
        played = team_row[field_played] if team_row else 0
        gf = team_row[field_gf] if team_row else None
        ga = team_row[field_ga] if team_row else None

        if prior_row:
            gf = data_sources.blend_stat(gf, played, prior_row[field_gf])
            ga = data_sources.blend_stat(ga, played, prior_row[field_ga])

        return gf, ga, played

    prior_home_row, prior_away_row = None, None
    if prior_stats and home:
        matched = data_sources.match_team_name(home["name"], list(prior_stats["teams"].keys()))
        prior_home_row = prior_stats["teams"].get(matched) if matched else None
    if prior_stats and away:
        matched = data_sources.match_team_name(away["name"], list(prior_stats["teams"].keys()))
        prior_away_row = prior_stats["teams"].get(matched) if matched else None

    home_gf, home_ga, home_played = _blended(home, prior_home_row, "home_played", "home_gf_avg", "home_ga_avg")
    away_gf, away_ga, away_played = _blended(away, prior_away_row, "away_played", "away_gf_avg", "away_ga_avg")

    # Valeurs par défaut si toujours aucune donnée exploitable (championnat
    # jamais couvert par football-data.co.uk + tout début de saison en cours)
    home_attack = (home_gf / lha) if home_gf is not None else 1.0
    home_defense = (home_ga / laa) if home_ga is not None else 1.0
    away_attack = (away_gf / laa) if away_gf is not None else 1.0
    away_defense = (away_ga / lha) if away_ga is not None else 1.0

    lambda_home = lha * home_attack * away_defense
    lambda_away = laa * away_attack * home_defense

    # Bornes de sécurité pour éviter les valeurs aberrantes sur petit échantillon
    lambda_home = max(0.2, min(4.5, lambda_home))
    lambda_away = max(0.2, min(4.5, lambda_away))

    return lambda_home, lambda_away


def get_topscorers(league_id: int, season: int) -> list:
    data = api_get("players/topscorers", {"league": league_id, "season": season})
    return data.get("response", [])


def estimate_scorer_probability(player_entry: dict, team_lambda: float, team_season_avg: float) -> dict:
    """
    lambda_joueur = (buts / apparitions) * (lambda_equipe_ce_match / moyenne_buts_equipe_saison)

    Le second facteur ajuste la forme du joueur au contexte du match du jour
    (ex: un match où l'équipe est favorite pour marquer beaucoup relève
    légèrement la probabilité du buteur, et inversement).
    """
    stats = player_entry["statistics"][0]
    goals = stats["goals"]["total"] or 0
    appearances = stats["games"]["appearences"] or 1

    goals_per_match = goals / appearances if appearances else 0
    adjustment = (team_lambda / team_season_avg) if team_season_avg > 0 else 1.0
    adjustment = max(0.4, min(2.0, adjustment))  # on limite l'ajustement

    lam_player = goals_per_match * adjustment
    prob = poisson_prob_scores(lam_player)

    return {
        "player": player_entry["player"]["name"],
        "photo": player_entry["player"]["photo"],
        "team_id": stats["team"]["id"],
        "goals_season": goals,
        "appearances": appearances,
        "prob_scores_pct": round(prob * 100, 1),
    }


# ---------------------------------------------------------------------------
# Assemblage : matchs du jour + pronostics
# ---------------------------------------------------------------------------

def build_today_predictions() -> list:
    season = current_season_year()
    today_str = date.today().isoformat()

    fixtures_data = api_get("fixtures", {"date": today_str})
    fixtures = fixtures_data.get("response", [])
    fixtures = [f for f in fixtures if f["league"]["id"] in LEAGUE_IDS]

    if not fixtures:
        return []

    # Pré-calcule les stats de classement + topscorers par ligue (1 appel chacun)
    leagues_needed = {f["league"]["id"] for f in fixtures}
    league_stats_cache = {}
    topscorers_cache = {}
    prior_stats_cache = {}
    for lid in leagues_needed:
        league_stats_cache[lid] = compute_league_standings_stats(lid, season)
        try:
            topscorers_cache[lid] = get_topscorers(lid, season)
        except Exception as e:
            print(f"Erreur topscorers ligue {lid}: {e}")
            topscorers_cache[lid] = []
        try:
            # Saison précédente (football-data.co.uk) pour lisser les débuts
            # de saison. Retourne None si le championnat n'est pas couvert.
            prior_stats_cache[lid] = data_sources.get_previous_season_stats(lid, season)
        except Exception as e:
            print(f"Erreur football-data.co.uk pour ligue {lid}: {e}")
            prior_stats_cache[lid] = None

    results = []
    for f in fixtures:
        league_id = f["league"]["id"]
        home = f["teams"]["home"]
        away = f["teams"]["away"]
        lstats = league_stats_cache[league_id]
        prior_stats = prior_stats_cache.get(league_id)

        lambda_home, lambda_away = estimate_match_goals(home["id"], away["id"], lstats, prior_stats)
        total_lambda = lambda_home + lambda_away
        prob_over25 = poisson_over_2_5(total_lambda)

        # Buteurs probables : on filtre les topscorers de la ligue qui jouent
        # aujourd'hui dans l'une des deux équipes.
        scorers = []
        for entry in topscorers_cache.get(league_id, []):
            team_id = entry["statistics"][0]["team"]["id"]
            if team_id == home["id"]:
                team_lambda, team_avg = lambda_home, lstats["league_avg_home_goals"]
            elif team_id == away["id"]:
                team_lambda, team_avg = lambda_away, lstats["league_avg_away_goals"]
            else:
                continue
            scorers.append(estimate_scorer_probability(entry, team_lambda, team_avg))

        scorers.sort(key=lambda s: s["prob_scores_pct"], reverse=True)

        results.append({
            "fixture_id": f["fixture"]["id"],
            "date": f["fixture"]["date"],
            "league": f["league"]["name"],
            "league_logo": f["league"]["logo"],
            "home_team": home["name"],
            "home_logo": home["logo"],
            "away_team": away["name"],
            "away_logo": away["logo"],
            "lambda_home": round(lambda_home, 2),
            "lambda_away": round(lambda_away, 2),
            "expected_total_goals": round(total_lambda, 2),
            "prob_over_2_5_pct": round(prob_over25 * 100, 1),
            "top_scorer_candidates": scorers[:6],
        })

    # Trie les matchs par probabilité de +2,5 buts décroissante
    results.sort(key=lambda r: r["prob_over_2_5_pct"], reverse=True)
    return results


# ---------------------------------------------------------------------------
# Routes Flask
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/predictions")
def api_predictions():
    try:
        preds = build_today_predictions()
        return jsonify({"date": date.today().isoformat(), "matches": preds})
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 400
    except requests.HTTPError as e:
        return jsonify({"error": f"Erreur API-Football: {e}"}), 502
    except Exception as e:
        return jsonify({"error": f"Erreur inattendue: {e}"}), 500


@app.route("/api/refresh", methods=["POST"])
def api_refresh():
    """Vide le cache pour forcer une nouvelle récupération des données."""
    for f in CACHE_DIR.glob("*.json"):
        f.unlink()
    return jsonify({"status": "cache vidé"})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)
