"""
Source de données complémentaire : football-data.co.uk
=========================================================

football-data.co.uk publie gratuitement, sans clé API ni authentification,
des fichiers CSV avec les résultats historiques (et cotes) des principaux
championnats européens depuis 1993. C'est un usage prévu et documenté par
le site lui-même (pas de scraping : ce sont des fichiers CSV téléchargeables
directement).

On l'utilise ici pour résoudre un problème classique des modèles de Poisson
appliqués au foot : en tout début de saison (peu de matchs joués), les
moyennes de buts d'une équipe sont peu fiables. On "mélange" alors les stats
de la saison en cours avec celles de la saison précédente, avec un poids qui
glisse progressivement vers la saison en cours au fil des journées
(shrinkage bayésien simple).
"""

import csv
import difflib
import io
import time
from datetime import date
from pathlib import Path

import requests

CACHE_DIR = Path(__file__).parent / "cache"
CACHE_DIR.mkdir(exist_ok=True)
CACHE_TTL_SECONDS = 24 * 3600  # les résultats d'une saison passée ne changent pas

# Correspondance entre l'ID de championnat API-Football et le code utilisé
# par football-data.co.uk. Seuls les championnats domestiques classiques y
# sont référencés (pas de coupes/compétitions internationales comme la
# Champions League, qui n'a pas d'équivalent dans ce format).
FDCOUK_LEAGUE_CODES = {
    39: "E0",    # Premier League (Angleterre)
    61: "F1",    # Ligue 1 (France)
    140: "SP1",  # La Liga (Espagne)
    135: "I1",   # Serie A (Italie)
    78: "D1",    # Bundesliga (Allemagne)
}


def _season_code(year: int) -> str:
    """Ex: année de départ de saison 2025 -> '2526' (saison 2025-26)."""
    return f"{str(year)[-2:]}{str(year + 1)[-2:]}"


def _cache_path(league_code: str, season_code: str) -> Path:
    return CACHE_DIR / f"fdcouk_{league_code}_{season_code}.csv"


def download_csv(league_code: str, season_code: str) -> str | None:
    """Télécharge (avec cache disque) le CSV d'un championnat/saison donnés."""
    cpath = _cache_path(league_code, season_code)
    if cpath.exists():
        age = time.time() - cpath.stat().st_mtime
        if age < CACHE_TTL_SECONDS:
            return cpath.read_text(encoding="latin-1")

    url = f"https://www.football-data.co.uk/mmz4281/{season_code}/{league_code}.csv"
    try:
        resp = requests.get(url, timeout=15)
        resp.raise_for_status()
        text = resp.text
        cpath.write_text(text, encoding="latin-1")
        return text
    except requests.RequestException as e:
        print(f"[football-data.co.uk] impossible de télécharger {url}: {e}")
        return None


def parse_team_stats(csv_text: str) -> dict:
    """
    Parse le CSV et retourne, par équipe, les moyennes de buts marqués/encaissés
    à domicile et à l'extérieur, plus les moyennes globales du championnat —
    exactement la même forme que `compute_league_standings_stats` dans app.py,
    mais indexée par NOM d'équipe (le CSV n'a pas d'ID numérique).
    """
    reader = csv.DictReader(io.StringIO(csv_text))
    agg = {}  # team_name -> {home: [gf, ga, played], away: [gf, ga, played]}
    home_goals_sum, home_played_sum = 0, 0
    away_goals_sum, away_played_sum = 0, 0

    for row in reader:
        try:
            home, away = row["HomeTeam"], row["AwayTeam"]
            fthg, ftag = int(row["FTHG"]), int(row["FTAG"])
        except (KeyError, ValueError, TypeError):
            continue  # ligne incomplète (fin de fichier, match pas encore joué, etc.)

        agg.setdefault(home, {"home": [0, 0, 0], "away": [0, 0, 0]})
        agg.setdefault(away, {"home": [0, 0, 0], "away": [0, 0, 0]})

        agg[home]["home"][0] += fthg
        agg[home]["home"][1] += ftag
        agg[home]["home"][2] += 1

        agg[away]["away"][0] += ftag
        agg[away]["away"][1] += fthg
        agg[away]["away"][2] += 1

        home_goals_sum += fthg
        home_played_sum += 1
        away_goals_sum += ftag
        away_played_sum += 1

    teams = {}
    for name, d in agg.items():
        h_gf, h_ga, h_played = d["home"]
        a_gf, a_ga, a_played = d["away"]
        teams[name] = {
            "home_played": h_played,
            "home_gf_avg": (h_gf / h_played) if h_played else None,
            "home_ga_avg": (h_ga / h_played) if h_played else None,
            "away_played": a_played,
            "away_gf_avg": (a_gf / a_played) if a_played else None,
            "away_ga_avg": (a_ga / a_played) if a_played else None,
        }

    return {
        "teams": teams,
        "league_avg_home_goals": (home_goals_sum / home_played_sum) if home_played_sum else 1.4,
        "league_avg_away_goals": (away_goals_sum / away_played_sum) if away_played_sum else 1.1,
    }


def get_previous_season_stats(api_football_league_id: int, current_season_year: int) -> dict | None:
    """
    Retourne les stats de la saison PRÉCÉDENTE pour un championnat donné
    (identifié par son ID API-Football), ou None si ce championnat n'a pas
    d'équivalent sur football-data.co.uk (ex: Champions League).
    """
    code = FDCOUK_LEAGUE_CODES.get(api_football_league_id)
    if not code:
        return None

    prev_season_code = _season_code(current_season_year - 1)
    csv_text = download_csv(code, prev_season_code)
    if not csv_text:
        return None

    return parse_team_stats(csv_text)


def match_team_name(name: str, candidates: list[str]) -> str | None:
    """
    football-data.co.uk utilise parfois des noms différents de l'API-Football
    (ex: 'Man City' vs 'Manchester City'). On fait un rapprochement flou.
    """
    if name in candidates:
        return name
    matches = difflib.get_close_matches(name, candidates, n=1, cutoff=0.6)
    return matches[0] if matches else None


def blend_stat(current_value: float | None, current_played: int,
                prior_value: float | None, full_trust_after: int = 10) -> float | None:
    """
    Mélange la valeur de la saison en cours avec celle de la saison précédente.
    Poids de la saison en cours = current_played / full_trust_after (plafonné à 1).
    Après `full_trust_after` matchs joués dans la saison en cours, on ne fait
    plus confiance qu'aux données actuelles.
    """
    if current_value is None and prior_value is None:
        return None
    if current_value is None:
        return prior_value
    if prior_value is None:
        return current_value

    weight_current = min(1.0, current_played / full_trust_after)
    return weight_current * current_value + (1 - weight_current) * prior_value
