const statusEl = document.getElementById("status");
const matchesEl = document.getElementById("matches");
const dateLabel = document.getElementById("date-label");
const refreshBtn = document.getElementById("refresh-btn");

function over25Class(pct) {
  if (pct >= 65) return "over25-high";
  if (pct >= 45) return "over25-mid";
  return "over25-low";
}

function formatTime(isoString) {
  const d = new Date(isoString);
  return d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
}

function renderMatch(m) {
  const scorersHtml = m.top_scorer_candidates.length
    ? m.top_scorer_candidates.map(s => `
        <div class="scorer-chip">
          <img src="${s.photo}" alt="${s.player}" onerror="this.style.visibility='hidden'">
          <span>${s.player}</span>
          <span class="scorer-prob">${s.prob_scores_pct}%</span>
        </div>
      `).join("")
    : `<span style="color:var(--text-dim); font-size:0.8rem;">Pas de données buteurs disponibles</span>`;

  return `
    <div class="match-card">
      <div class="match-header">
        <span class="league-tag"><img src="${m.league_logo}" alt=""> ${m.league}</span>
        <span class="match-time">${formatTime(m.date)}</span>
      </div>
      <div class="teams">
        <div class="team home"><img src="${m.home_logo}" alt=""> ${m.home_team}</div>
        <span class="vs">vs</span>
        <div class="team away"><img src="${m.away_logo}" alt=""> ${m.away_team}</div>
      </div>
      <div class="over25-badge ${over25Class(m.prob_over_2_5_pct)}">
        +2,5 buts : ${m.prob_over_2_5_pct}%
      </div>
      <div class="expected-goals">
        Buts attendus : ${m.home_team} ${m.lambda_home} — ${m.lambda_away} ${m.away_team}
        (total ${m.expected_total_goals})
      </div>
      <div class="scorers-title">Buteurs probables</div>
      <div class="scorers-list">${scorersHtml}</div>
    </div>
  `;
}

async function loadPredictions() {
  statusEl.style.display = "block";
  statusEl.textContent = "Chargement des matchs du jour…";
  matchesEl.innerHTML = "";

  try {
    const res = await fetch("/api/predictions");
    const data = await res.json();

    if (!res.ok) {
      statusEl.innerHTML = `<div class="error-box">${data.error || "Erreur inconnue"}</div>`;
      return;
    }

    dateLabel.textContent = `📅 ${data.date}`;

    if (!data.matches || data.matches.length === 0) {
      statusEl.textContent = "Aucun match trouvé aujourd'hui dans les championnats suivis.";
      return;
    }

    statusEl.style.display = "none";
    matchesEl.innerHTML = data.matches.map(renderMatch).join("");
  } catch (err) {
    statusEl.innerHTML = `<div class="error-box">Erreur réseau : ${err.message}</div>`;
  }
}

refreshBtn.addEventListener("click", async () => {
  refreshBtn.disabled = true;
  refreshBtn.textContent = "⏳ Rafraîchissement…";
  await fetch("/api/refresh", { method: "POST" });
  await loadPredictions();
  refreshBtn.disabled = false;
  refreshBtn.textContent = "🔄 Rafraîchir les données";
});

loadPredictions();
